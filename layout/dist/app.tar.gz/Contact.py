import flet as f
from colors import ColorsApp

colors = ColorsApp()


class Contact:
    def __init__(self) -> None:
        self.body_contact = f.ResponsiveRow(
            controls=[
                f.Container(
                    alignment=f.alignment.center,
                    bgcolor=colors.Light_orange,
                    border_radius=f.border_radius.only(
                        top_left=30,
                        top_right=30
                    ),
                    padding=0,
                    margin=f.margin.symmetric(vertical=-30),
                    content=f.Column(
                        col={"xs": 12, "sm": 12, "md": 12, "lg": 12},
                        controls=[
                            f.Text("Contact")
                        ],
                    )
                )
            ]
        )
