import flet as f
from colors import ColorsApp
from login import User

colors = ColorsApp()


class Home:
    def __init__(self, page: f.Page) -> None:
        self.bots = {}
        self.page = page
        self._user = None | User

        self.image_play = f.Image(
            src="assets/image/coin.png",
            fit=f.ImageFit.CONTAIN,
            width=40,
            height=40
        )
        self.text_play = f.Text(
            "Play",
            color="white",
            size=20,
            weight="bold"
        )
        self.play_button = f.Container(
            padding=10,
            margin=0,
            on_click=lambda e: print("play"),
            content=f.Column(
                controls=[
                    f.Container(
                        content=self.image_play
                    ),
                    self.text_play
                ]
            )
        )
        self.image_add_bot = f.Image(
            src="assets/image/panda.png",
            fit=f.ImageFit.CONTAIN,
            width=40,
            height=40
        )
        self.text_add_bot = f.Text(
            "Add Bot",
            color="white",
            size=20,
            weight="bold"
        )
        self.add_bot_buttom = f.Container(
            padding=10,
            margin=0,
            on_click=lambda e: print("Add Bot"),
            content=f.Column(
                controls=[
                    f.Container(
                        content=self.image_add_bot
                    ),
                    self.text_add_bot
                ]
            )
        )
        self.image_settings = f.Image(
            src="assets/image/live_support_opt.png",
            fit=f.ImageFit.CONTAIN,
            width=40,
            height=40
        )
        self.text_settings = f.Text(
            "Settings",
            color="white",
            size=20,
            weight="bold"
        )
        self.settings_buttom = f.Container(
            padding=10,
            margin=0,
            on_click=lambda e: print("Settings"),
            content=f.Column(
                controls=[
                    self.image_settings,
                    self.text_settings
                ]
            )
        )
        self.card_home = f.Card(
            elevation=30,
            color=colors.Light_purple,
            shadow_color=colors.Dark_purple,
            content=f.Container(
                border_radius=30,
                expand=True,
                # bgcolor=colors.Light_purple,
                content=f.Row(
                    col={"xs": 12, "sm": 12, "md": 12, "lg": 12},
                    controls=[
                        self.play_button,
                        self.add_bot_buttom,
                        self.settings_buttom,
                    ],
                    alignment=f.MainAxisAlignment.SPACE_AROUND
                )
            )
        )
        self.text_welcome = f.Text("none", size=20)
        self.welcome_card = f.Card(
            elevation=30,
            color=colors.Light_orange,
            shadow_color=colors.Dark_orange,
            content=f.Container(
                border_radius=30,
                expand=True,
                padding=10,
                content=f.Row(
                    col={"xs": 6, "sm": 6, "md": 12, "lg": 12},
                    controls=[
                        self.text_welcome
                    ]
                )
            )
        )
        self.card_bots = f.Card(
            elevation=30,
            color=colors.Light_orange,
            shadow_color=colors.Dark_orange,
        )
        self.body_home = f.ResponsiveRow(
            controls=[
                f.Container(
                    alignment=f.alignment.center,
                    bgcolor=colors.Light_orange,
                    border_radius=f.border_radius.only(
                        top_left=30,
                        top_right=30
                    ),
                    padding=0,
                    margin=f.margin.symmetric(vertical=-30),
                    content=f.Column(
                        col={"xs": 12, "sm": 12, "md": 12, "lg": 12},
                        controls=[
                            f.Row(
                                controls=[
                                    self.welcome_card,
                                ],
                                alignment=f.MainAxisAlignment.SPACE_EVENLY
                            ),
                            f.Row(
                                controls=[
                                    self.card_home,
                                ],
                                alignment=f.MainAxisAlignment.SPACE_EVENLY
                            ),
                            f.Row(
                                controls=[
                                    self.card_bots,
                                ],
                                alignment=f.MainAxisAlignment.SPACE_EVENLY
                            )
                        ]
                    )
                )
            ]
        )

    @property
    def user(self):
        return self._user

    @user.setter
    def user(self, value):
        self._user = value

    def insert_card_bot(self, cards):
        for i in cards:
            pass

    def home_responsive(self, larg: str, page: f.Page):
        if not isinstance(larg, str):
            return
        if larg == "low":
            for i in (
                self.image_play, self.image_add_bot, self.image_settings
            ):
                i.width = 25
                i.height = 25
            for i in (
                self.text_play, self.text_add_bot, self.text_settings
            ):
                i.size = 10
            self.card_home.width = page.width - 100
        elif larg == "small":
            for i in (
                self.image_play, self.image_add_bot, self.image_settings
            ):
                i.width = 30
                i.height = 30
            for i in (
                self.text_play, self.text_add_bot, self.text_settings
            ):
                i.size = 13
            self.card_home.width = page.width - 100
        elif larg == "medium":
            for i in (
                self.image_play, self.image_add_bot, self.image_settings
            ):
                i.width = 35
                i.height = 35
            for i in (
                self.text_play, self.text_add_bot, self.text_settings
            ):
                i.size = 16
            self.card_home.width = page.width - 200
        elif larg == "larg":
            for i in (
                self.image_play, self.image_add_bot, self.image_settings
            ):
                i.width = 40
                i.height = 40
            for i in (
                self.text_play, self.text_add_bot, self.text_settings
            ):
                i.size = 20
            self.card_home.width = page.width - 300
