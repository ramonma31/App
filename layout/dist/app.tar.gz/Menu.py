import flet as f
from colors import ColorsApp
from text_style import TextStyleApp

colors = ColorsApp()
text = TextStyleApp()


class Menu:
    def __init__(self) -> None:

        self.card_menu = f.Card(
            elevation=30,
            content=f.Container(
                border_radius=30,
                bgcolor=colors.Light_purple
            )
        )
        self.body_menu = f.ResponsiveRow(
            controls=[
                f.Container(
                    alignment=f.alignment.center,
                    bgcolor=colors.Light_orange,
                    border_radius=f.border_radius.only(
                        top_left=30,
                        top_right=30
                    ),
                    padding=0,
                    margin=f.margin.symmetric(vertical=-30),
                    content=f.Column(
                        col={"xs": 12, "sm": 12, "md": 12, "lg": 12},
                        controls=[
                            self.card_menu
                        ],
                    )
                )
            ]
        )
