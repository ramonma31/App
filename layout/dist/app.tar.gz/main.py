import flet as f
from actions_buttons import ActionsMenu
from appMenu import MenuApp
from colors import ColorsApp
from Contact import Contact
from Home import Home
from Menu import Menu
from login import User, NumberPhone, Login, BirthDate
from supabase import Client, create_client
# import os
# BirthDate()
# u = User()
SUPABASE_URL = "https://houmarmlwjtrwgewztor.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhvdW1hcm1sd2p0cndnZXd6dG9yIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MDczNjgzODQsImV4cCI6MjAyMjk0NDM4NH0.R_soji7iWXEZDne04EEa4NSkOa8pHP8A9pid5QsOnJg"

url: str = SUPABASE_URL
key: str = SUPABASE_KEY
base: Client = create_client(url, key)


def main(page: f.Page):

    actions_menu = ActionsMenu(page=page)
    colors = ColorsApp()
    menu = Menu()
    contact = Contact()
    home = Home(page=page)
    login = Login(page=page, data=base, home=home)
    menu_app = MenuApp(page=page, home=home)

    def page_resize(e):
        if page.width < 350.0:
            menu_app.menu_responsive("low", page=page)
            home.home_responsive("low", page=page)
            actions_menu.actions_responsive("low", page=page)
        if page.width < 500.0 and page.width > 350.0:
            menu_app.menu_responsive("small", page=page)
            home.home_responsive("small", page=page)
            actions_menu.actions_responsive("small", page=page)
        if page.width > 500.0 and page.width < 920.0:
            menu_app.menu_responsive("medium", page=page)
            home.home_responsive("medium", page=page)
            actions_menu.actions_responsive("medium", page=page)
        if page.width > 920.0:
            menu_app.menu_responsive("larg", page=page)
            home.home_responsive("larg", page=page)
            actions_menu.actions_responsive("larg", page=page)
        page.update()

    def route_change(route):
        page.views.clear()
        page.views.append(login.display_login)

        if page.route == "/menu":
            page.views.append(
                f.View(
                    route="menu",
                    controls=[
                        menu_app.appmenu,
                        actions_menu.action_section,
                        menu.body_menu,
                    ],
                    spacing=0
                )
            )

        if page.route == "/home":
            page.views.append(
                f.View(
                    "menu",
                    controls=[
                        menu_app.appmenu,
                        actions_menu.action_section,
                        home.body_home
                    ],
                    spacing=0
                )
            )

        if page.route == "/contact":
            page.views.append(
                f.View(
                    "menu",
                    controls=[
                        menu_app.appmenu,
                        actions_menu.action_section,
                        contact.body_contact
                    ],
                    spacing=0
                )
            )
        page.update()

    def view_pop(view):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route)

    page.padding = 0
    page.spacing = 0
    page.on_resize = page_resize
    page.scroll = True,
    page.auto_scroll = True
    page.fonts = {
        "protest_strike": "/fonts/ProtestStrike-Regular.ttf"
    }
    page.theme = f.Theme(font_family="protest_strike")
    page.bgcolor = colors.Dark_orange
    page.update()


f.app(target=main)
